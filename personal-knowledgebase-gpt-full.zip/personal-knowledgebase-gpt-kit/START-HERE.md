# 快速开始

完整说明见 [README](README.md)，原版功能对照见 [复核报告](AUDIT.md)。

1. 解压到长期保存位置。
2. 在 Codex 打开 `knowledgebase` 作为本地项目。
3. 发送：“开始学习，先通过提问了解我的背景、目标和偏好，每次只问一个问题；不确定的可以先跳过，并自动保存。”
4. 如使用 Obsidian，也将同一个 `knowledgebase` 文件夹作为 vault 打开。

需要全局插件时运行 `install-plugin.ps1`；已有 Obsidian 库先做目录核对，不能直接覆盖初始化。安装步骤、材料放置、常用命令、保存与验证范围均已写入 README。
