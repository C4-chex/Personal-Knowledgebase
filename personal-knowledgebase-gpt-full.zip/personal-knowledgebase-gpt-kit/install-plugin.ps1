param([string]$CodexPath)
$ErrorActionPreference = 'Stop'
if (-not $CodexPath) {
    $found = Get-Command codex -ErrorAction SilentlyContinue
    if ($found) { $CodexPath = $found.Source }
}
if (-not $CodexPath) { throw 'Codex CLI was not found. Open the supplied knowledgebase folder in Codex to use its included project skill, or pass -CodexPath with the CLI path.' }
$marketplacePath = Join-Path $PSScriptRoot 'marketplace'
& $CodexPath plugin marketplace add $marketplacePath
if ($LASTEXITCODE -ne 0) { throw 'Marketplace registration failed. The supplied knowledgebase folder remains usable.' }
& $CodexPath plugin add 'personal-knowledgebase-gpt@knowledgebase-local'
if ($LASTEXITCODE -ne 0) { throw 'Plugin installation failed. Keep this folder and inspect the Codex message.' }
Write-Host 'Installed. Open a local project in Codex and ask to initialize your learning knowledgebase.'
